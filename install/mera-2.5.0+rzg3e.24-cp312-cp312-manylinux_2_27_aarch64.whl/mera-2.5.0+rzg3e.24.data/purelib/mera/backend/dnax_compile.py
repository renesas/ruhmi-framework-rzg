# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from pathlib import Path
from .utils import get_backend_binaries_dict, check_plan_json
from ..utils import cmd, find_tool

_DNAX_BIN_ID = 'mera_dnax'

def generate_dnax_compile_cfg(user_cfg):
  return {
    'compiler_workers' : int(user_cfg.get('compiler_workers', 1)),
    'target' : str(user_cfg.get('target', 'IP')),
    'dma_mode' : str(user_cfg.get('dma_mode', 'Full'))
  }

def has_dnax_regions(compile_loc):
  return _DNAX_BIN_ID in get_backend_binaries_dict(compile_loc)

def meradnax_compile(compile_loc, prj, compile_cfg = {}):
  plan_loc = Path(check_plan_json(compile_loc))
  cfg_json = generate_dnax_compile_cfg(compile_cfg)
  from ..deploy_project import ArtifactFileType
  compile_cfg_loc = prj.save_artifact(f'mdnax_compile_cfg.json', ArtifactFileType.JSON, 'mera2_dcfg', cfg_json)
  compile_bins = get_backend_binaries_dict(compile_loc)
  cmd(f'{find_tool("mera_dnax_compile")} --plan_path {plan_loc} -c {compile_cfg_loc}')
  cmd(f'{find_tool("mera_dnax_link")} --plan_path {plan_loc}')
  return plan_loc
