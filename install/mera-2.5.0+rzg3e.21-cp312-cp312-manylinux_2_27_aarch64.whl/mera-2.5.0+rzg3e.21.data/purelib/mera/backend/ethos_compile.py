# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from pathlib import Path
from .utils import get_backend_binaries_dict
from ..utils import cmd
import os

_ETHOS_U55_DEFAULT_CONFIG = '''
[System_Config.RZG3E_SRAM_64]
; Ethos-U55 core clock frequency (NPUCLK) in Hz.
; e.g., `core_clock=500e6` for 500MHz.
core_clock=1000e6

; Memory type connected to each AXI port.
; Do not modify this even if the actual memory type is different.
axi0_port=Sram
axi1_port=OffChipFlash

; Characteristics of the memory connected to the AXI0 port,
; i.e., the memory where the tensor arena is placed.
; Only 'Sram_clock_scale' should be modified.
; Specify the value for the memory where the tensor arena is placed,
; regardless of whether it is SRAM or not.
;
; 'Sram_clock_scale' is calculated as follows:
;
;   Sram_clock_scale = (memory_clock_in_Hz * memory_bus_width_in_bits) /
;                      (NPUCLK * 64)
;
; For example, if you use internal SRAM for the tensor arena,
; this parameter is calculated as follows:
;
;   Sram_clock_scale = (ICLK * 64) / (NPUCLK * 64) = ICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
Sram_clock_scale=1.0
Sram_burst_length=64
Sram_read_latency=30
Sram_write_latency=30

; Characteristics of the memory connected to AXI1 port,
; i.e., the memory where the tflite model is placed.
; 'OffChipFlash_clock_scale' should be modified only when
; the memory for the tensor arena is faster than the memory
; for the tflite model.
; All other parameters should always be left as default.
; Specify the value for the memory where the tflite model is placed,
; regardless of whether it is OffChip-Flash or not.
;
; 'OffChipFlash_clock_scale' is calculated with the same formula as
; 'Sram_clock_scale'.  For example, if you use internal MRAM for
; tflite model, this parameter is calculated as follows:
;
;   OffChipFlash_clock_scale = (MRICLK * 64) / (NPUCLK * 64) = MRICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
OffChipFlash_clock_scale=1.0
OffChipFlash_burst_length=64
OffChipFlash_read_latency=30
OffChipFlash_write_latency=30


[System_Config.RZG3E_SRAM_1]
; Ethos-U55 core clock frequency (NPUCLK) in Hz.
; e.g., `core_clock=500e6` for 500MHz.
core_clock=1000e6

; Memory type connected to each AXI port.
; Do not modify this even if the actual memory type is different.
axi0_port=Sram
axi1_port=OffChipFlash

; Characteristics of the memory connected to the AXI0 port,
; i.e., the memory where the tensor arena is placed.
; Only 'Sram_clock_scale' should be modified.
; Specify the value for the memory where the tensor arena is placed,
; regardless of whether it is SRAM or not.
;
; 'Sram_clock_scale' is calculated as follows:
;
;   Sram_clock_scale = (memory_clock_in_Hz * memory_bus_width_in_bits) /
;                      (NPUCLK * 64)
;
; For example, if you use internal SRAM for the tensor arena,
; this parameter is calculated as follows:
;
;   Sram_clock_scale = (ICLK * 64) / (NPUCLK * 64) = ICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
Sram_clock_scale=1.0
Sram_burst_length=1
Sram_read_latency=30
Sram_write_latency=30

; Characteristics of the memory connected to AXI1 port,
; i.e., the memory where the tflite model is placed.
; 'OffChipFlash_clock_scale' should be modified only when
; the memory for the tensor arena is faster than the memory
; for the tflite model.
; All other parameters should always be left as default.
; Specify the value for the memory where the tflite model is placed,
; regardless of whether it is OffChip-Flash or not.
;
; 'OffChipFlash_clock_scale' is calculated with the same formula as
; 'Sram_clock_scale'.  For example, if you use internal MRAM for
; tflite model, this parameter is calculated as follows:
;
;   OffChipFlash_clock_scale = (MRICLK * 64) / (NPUCLK * 64) = MRICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
OffChipFlash_clock_scale=1.0
OffChipFlash_burst_length=1
OffChipFlash_read_latency=30
OffChipFlash_write_latency=30


[System_Config.RZG3E_DDR_FAST]
; Ethos-U55 core clock frequency (NPUCLK) in Hz.
; e.g., `core_clock=500e6` for 500MHz.
core_clock=1000e6

; Memory type connected to each AXI port.
; Do not modify this even if the actual memory type is different.
axi0_port=Sram
axi1_port=OffChipFlash

; Characteristics of the memory connected to the AXI0 port,
; i.e., the memory where the tensor arena is placed.
; Only 'Sram_clock_scale' should be modified.
; Specify the value for the memory where the tensor arena is placed,
; regardless of whether it is SRAM or not.
;
; 'Sram_clock_scale' is calculated as follows:
;
;   Sram_clock_scale = (memory_clock_in_Hz * memory_bus_width_in_bits) /
;                      (NPUCLK * 64)
;
; For example, if you use internal SRAM for the tensor arena,
; this parameter is calculated as follows:
;
;   Sram_clock_scale = (ICLK * 64) / (NPUCLK * 64) = ICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
Sram_clock_scale=1.0
Sram_burst_length=32
Sram_read_latency=6
Sram_write_latency=4

; Characteristics of the memory connected to AXI1 port,
; i.e., the memory where the tflite model is placed.
; 'OffChipFlash_clock_scale' should be modified only when
; the memory for the tensor arena is faster than the memory
; for the tflite model.
; All other parameters should always be left as default.
; Specify the value for the memory where the tflite model is placed,
; regardless of whether it is OffChip-Flash or not.
;
; 'OffChipFlash_clock_scale' is calculated with the same formula as
; 'Sram_clock_scale'.  For example, if you use internal MRAM for
; tflite model, this parameter is calculated as follows:
;
;   OffChipFlash_clock_scale = (MRICLK * 64) / (NPUCLK * 64) = MRICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
OffChipFlash_clock_scale=1.0
OffChipFlash_burst_length=32
OffChipFlash_read_latency=6
OffChipFlash_write_latency=4



[System_Config.RZG3E_DDR_SLOW]
; Ethos-U55 core clock frequency (NPUCLK) in Hz.
; e.g., `core_clock=500e6` for 500MHz.
core_clock=1000e6

; Memory type connected to each AXI port.
; Do not modify this even if the actual memory type is different.
axi0_port=Sram
axi1_port=OffChipFlash

; Characteristics of the memory connected to the AXI0 port,
; i.e., the memory where the tensor arena is placed.
; Only 'Sram_clock_scale' should be modified.
; Specify the value for the memory where the tensor arena is placed,
; regardless of whether it is SRAM or not.
;
; 'Sram_clock_scale' is calculated as follows:
;
;   Sram_clock_scale = (memory_clock_in_Hz * memory_bus_width_in_bits) /
;                      (NPUCLK * 64)
;
; For example, if you use internal SRAM for the tensor arena,
; this parameter is calculated as follows:
;
;   Sram_clock_scale = (ICLK * 64) / (NPUCLK * 64) = ICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
Sram_clock_scale=1.0
Sram_burst_length=16
Sram_read_latency=40
Sram_write_latency=34

; Characteristics of the memory connected to AXI1 port,
; i.e., the memory where the tflite model is placed.
; 'OffChipFlash_clock_scale' should be modified only when
; the memory for the tensor arena is faster than the memory
; for the tflite model.
; All other parameters should always be left as default.
; Specify the value for the memory where the tflite model is placed,
; regardless of whether it is OffChip-Flash or not.
;
; 'OffChipFlash_clock_scale' is calculated with the same formula as
; 'Sram_clock_scale'.  For example, if you use internal MRAM for
; tflite model, this parameter is calculated as follows:
;
;   OffChipFlash_clock_scale = (MRICLK * 64) / (NPUCLK * 64) = MRICLK / NPUCLK
;
; This parameter must be a float value between 0.0 and 1.0.
OffChipFlash_clock_scale=1.0
OffChipFlash_burst_length=16
OffChipFlash_read_latency=40
OffChipFlash_write_latency=34



; ------------------------------------------------------------
; Memory Mode
;

; Specify `--memory-mode Sram_Only` if the memory for the tensor arena is
; slower than or equal to the memory for the model data.
[Memory_Mode.Sram_Only]
const_mem_area=Axi0
arena_mem_area=Axi0

; Specify `--memory-mode Shared_Sram` if the memory for the tensor arena is
; faster than the memory for the model data. This memory mode allows the compiled
; model to use a part of the tensor arena as cache for the weights in the model data.
[Memory_Mode.Shared_Sram]
const_mem_area=Axi1
arena_mem_area=Axi0
'''

def ethos_compile(compile_loc, config=None, sys_config='RZG3E_SRAM_64', memory_mode='Sram_Only',
    accel_config='ethos-u55-256', optimise='Performance', verbose_all=False, backend_bin_id='ethos_u55'):
  compile_bins = get_backend_binaries_dict(compile_loc)
  if config is None:
    cfg_path = compile_loc / f'{accel_config}_system_config.ini'
    if not os.path.isfile(cfg_path):
      with open(cfg_path, 'w') as f:
        f.write(_ETHOS_U55_DEFAULT_CONFIG)
      config = cfg_path
  assert config is not None
  for c_loc in compile_bins.get(backend_bin_id, []):
    c_loc = Path(c_loc).resolve()
    vbse = '--verbose-all' if verbose_all else ''
    cfg_loc = Path(config)
    cmd(f'vela --config {cfg_loc} --system-config {sys_config} --memory-mode {memory_mode}'
        + f' --accelerator-config {accel_config} --optimise {optimise} --output-dir {c_loc} {vbse} {c_loc}/model.tflite')
