# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from pathlib import Path
from .ethos_compile import ethos_compile
from .utils import get_backend_binaries_dict
from ..utils import cmd

_CCODEGEN_BIN_ID = 'mera_c99_source_cpu'
_ETHOS_CODEGEN_BIN_ID = 'mera_c99_source_ethos_u55'

def ccodegen_compile(compile_loc, exec_loc, suffix='', weight_location='flash', use_x86=True, use_ospi=False):
  compile_bins = get_backend_binaries_dict(compile_loc, add_unit_name=True)
  c_out_dir = Path(compile_loc) / 'src'
  __GCC_THREADS = 8
  __use_ospi = '--use-ospi' if use_ospi else ''

  c_out_dir.mkdir(exist_ok=True)
  cmd(f'{exec_loc/"c_codegen"} {compile_loc} {c_out_dir} {suffix} {__use_ospi}')
  for c_loc,unit_name in compile_bins.get(_CCODEGEN_BIN_ID, []):
      c_loc = Path(c_loc).resolve()
      __use_x86 = 'x86' if use_x86 else ''
      cmd(f'{exec_loc/"c_codegen"} {c_loc/"model.merair"} {exec_loc/"templates"} {exec_loc/"kernel_library"} {unit_name} {c_out_dir} {weight_location} {suffix} {__use_x86} {__use_ospi}')

def has_ethos_ccodegen_regions(compile_loc):
  return _ETHOS_CODEGEN_BIN_ID in get_backend_binaries_dict(compile_loc)

def ethos_ccodegen_compile(compile_loc, ccodegen_loc, suffix='', config=None, enable_ospi=False, sys_config='RA8P1', memory_mode='Sram_Only',
    accel_config='ethos-u55-256', optimise='Performance', verbose_all=False):
  ethos_compile(compile_loc, config, sys_config, memory_mode, accel_config, optimise, verbose_all, _ETHOS_CODEGEN_BIN_ID)
  # compile_loc already is in subdirectory 'compilation'
  cmd(f'{ccodegen_loc / "vela_optimized_to_source"} {str(Path(compile_loc).parent.resolve())} {suffix} {"--use-ospi" if enable_ospi else ""}')
