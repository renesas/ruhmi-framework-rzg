# ~~ This file is auto-generated. Please do not touch. ~~
__version__ = "2.5.0"
__githash__ = "be798a34d86b"
